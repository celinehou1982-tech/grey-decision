# 灰度决策教练 (Grey Decision Coach)

基于巴达拉克《灰度决策》(Managing in the Grey) 五大问题框架的深度引导式决策分析工具。

## 适用场景

当你面对**没有明确答案的高风险决策**时——利益冲突、道德困境、两难抉择——这个工具通过系统性的问答引导你看到全貌，而不是替你做决定。

## 安装

将 `grey-decision/` 文件夹复制到你的 Claude Code skills 目录：

```bash
cp -r grey-decision ~/.claude/skills/
```

## 首次使用前的配置

打开 `SKILL.md`，找到底部"文档管理"部分，将存储路径改为你自己的目录：

```
### 文档管理
- 决策文档目录：`~/你的路径/`
```

同样修改 `references/output-template.md` 顶部的存储位置。

## 使用方式

在 Claude Code 中描述你面对的决策，例如：

- "我有一个决策想分析..."
- "我面对一个两难的选择..."
- "灰度决策"

Skill 会自动触发，引导你走过完整的五维度分析流程。

## 文件结构

```
grey-decision/
├── SKILL.md                    # 主编排器（流程控制）
└── references/
    ├── framework.md            # 五大问题框架
    ├── challenge-matrix.md     # 交叉质疑矩阵
    ├── case-studies.md         # 书中案例库
    ├── red-flags.md            # 高风险信号检测
    ├── process-guide.md        # 流程定义与质量标准
    ├── output-template.md      # 总结文档模板
    └── user-extensions.md      # 个人案例库（自动积累）
```

## 方法论来源

Joseph L. Badaracco Jr.,《Managing in the Grey: Five Timeless Questions for Resolving Your Toughest Problems at Work》(Harvard Business Review Press, 2016)

中文版：《灰度决策：如何处理复杂、棘手、高风险的难题》

## 版权说明

本工具的引导逻辑基于巴达拉克教授的公开方法论框架进行结构化实现，仅供个人学习和决策辅助使用。强烈建议阅读原书以获得完整理解。
